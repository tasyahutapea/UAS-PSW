<?php $__env->startSection('title', 'Basket Viladelima'); ?>

<?php $__env->startSection('active-home', 'active'); ?>

<?php $__env->startSection('content-header'); ?>	

    <div class="banner">
        <div class="banner-top">
            <h2>Badminton Field</h2>
        </div>
        <div class="now">
            <a class="morebtn" href="<?php echo e(route('booking')); ?>">Pesan Sekarang</a>
            <div class="clearfix"> </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="sap_tabs">
        <div class="container">

            <div style="margin-bottom: 10px; display: flex; justify-content: center; align-items:center;">

                <img src="<?php echo e(asset('lapangan/lapanganbasket1.png')); ?>" class="img-responsive" style="width: 500px; height:300px;" alt="error" />
                
            </div>
            <p style="text-align: center; text-transform: uppercase; font-size: 20px; font-weight: 600;">Lapangan 1</p>
            <p style="text-align: center; font-size: 18px; margin-bottom: 20px">( INDOOR )</p>
            
            <div style="margin-bottom: 10px; display: flex; justify-content: center; align-items:center;">
                
                <img src="<?php echo e(asset('lapangan/lapanganbasket2.jpeg')); ?>" class="img-responsive" style="width: 500px; height:300px;" alt="" />
                
            </div>
            <p style="text-align: center; text-transform: uppercase; font-size: 20px; font-weight: 600;">Lapangan 2</p>
            <p style="text-align: center; font-size: 18px; margin-bottom: 20px">( OUTDOOR )</p>
            
           

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\Aplikasi-Pemesanan-Lapangan-Basket-Villadelima-main\resources\views/index.blade.php ENDPATH**/ ?>