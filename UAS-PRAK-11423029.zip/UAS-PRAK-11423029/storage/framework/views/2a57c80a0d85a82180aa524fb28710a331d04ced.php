<!--A Design by W3layouts 
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html>
<head>
<title><?php echo $__env->yieldContent('title'); ?></title>
<link href="<?php echo e(asset('assets2/css/bootstrap.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo e(asset('/assets/vendor/jquery/jquery.js')); ?>"></script>
<!-- Custom Theme files -->
<!--theme-style-->
<link href="<?php echo e(asset('assets2/css/style.css')); ?>" rel="stylesheet" type="text/css" media="all" />	
<!--//theme-style-->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="I wear Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script type="text/javascript" src="<?php echo e(asset('assets2/js/html2canvas.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets2/js/move-top.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets2/js/easing.js')); ?>"></script>
<!--fonts-->
<link href='<?php echo e(url('fonts.googleapis.com/css?family=Lato:100,300,400,700,900')); ?>' rel='stylesheet' type='text/css'>
<link href='<?php echo e(url('fonts.googleapis.com/css?family=Montez')); ?>' rel='stylesheet' type='text/css'>
<link href="<?php echo e(asset('/assets/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
<!--//fonts-->
<!-- start menu -->
<!--//slider-script-->
<script src="<?php echo e(asset('assets2/js/easyResponsiveTabs.js')); ?>" type="text/javascript"></script>
		    <script type="text/javascript">
			    $(document).ready(function () {
			        $('#horizontalTab').easyResponsiveTabs({
			            type: 'default', //Types: default, vertical, accordion           
			            width: 'auto', //auto or any width like 600px
			            fit: true   // 100% fit in a container
			        });
			    });
				
</script>	
		  		 <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
	<!-- js -->
		 <script src="<?php echo e(asset('assets2/js/bootstrap.js')); ?>"></script>
	<!-- js -->
<script src="<?php echo e(asset('assets2/js/simpleCart.min.js')); ?>"> </script>
<link href="<?php echo e(asset('assets2/css/memenu.css')); ?>" rel="stylesheet" type="text/css" media="all" />
<!-- start menu -->
<script type="text/javascript" src="<?php echo e(asset('assets2/js/memenu.js')); ?>"></script>
<script>$(document).ready(function(){$(".memenu").memenu();});</script>	
<!-- /start menu -->
</head>
<body>
	<!--header-->
	<div class="header-info">
		<div class="container">
			<div class="header-top-in">

				<ul class="support">
					<li><a href="https://wa.me/+6281336680539"><i class="fab fa-whatsapp-square"></i>Whatsapp</a></li>
				</ul>
				<ul class=" support-right">
					<?php if(Auth::check()): ?>
						<li><a href="<?php echo e(route('dashboard')); ?>"><i class="glyphicon glyphicon-user" class="men"> </i><?php echo e(Auth::user()->name); ?></a></li>
						<li><a href="<?php echo e(route('user.keluar')); ?>" onclick="event.preventDefault(); document.getElementById('keluar').submit();"><i class="glyphicon glyphicon-arrow-right" class="men"> </i>Logout</a></li>
						<form action="<?php echo e(route('user.keluar')); ?>" method="POST" id="keluar">
							<?php echo csrf_field(); ?>
						</form>
					<?php else: ?>
						<li><a href="<?php echo e(route('masuk')); ?>"><i class="glyphicon glyphicon-user" class="men"> </i>Masuk</a></li>
						<li><a href="<?php echo e(route('daftar')); ?>"><i class="glyphicon glyphicon-lock" class="tele"> </i>Daftar</a></li>
					<?php endif; ?>
				</ul>
				<div class="clearfix"> </div>
			</div>
		</div>
	</div>
	<div class="header <?php echo $__env->yieldContent('header5'); ?>">
		<div class="header-top">

			<div class="header-bottom">
				<div class="container">
					<div class="logo">
						<h1><a href="index.html">Field<span>Basket</span></a></h1>
					</div>
					<!---->

					<div class="top-nav">
						<ul class="memenu skyblue">
							<li class="<?php echo $__env->yieldContent('active-home'); ?>"><a href="<?php echo e(route('index')); ?>">Home</a></li>
							<li class="<?php echo $__env->yieldContent('active-tentang'); ?>" class="grid"><a href="<?php echo e(route('tentang')); ?>">Tentang</a></li>
							<li class="<?php echo $__env->yieldContent('active-cara-pemesanan'); ?>" class="grid"><a href="<?php echo e(route('cara-pemesanan')); ?>">Cara Pemesanan</a></li>
							<li class="<?php echo $__env->yieldContent('active-booking'); ?>" class="grid"><a href="<?php echo e(route('booking')); ?>">Pesan</a></li>
							<li class="<?php echo $__env->yieldContent('active-jadwal'); ?>" class="grid"><a href="<?php echo e(route('jadwal')); ?>">Jadwal</a></li>
							<?php if(Auth::check()): ?>
								<li class="<?php echo $__env->yieldContent('active-dashboard'); ?>" class="grid"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
							<?php endif; ?>
						</ul>
						<div class="clearfix"> </div>
					</div>
					<!---->

					<div class="clearfix"> </div>
					<!---->
				</div>
				<div class="clearfix"> </div>
			</div>
		</div>

        <?php echo $__env->yieldContent('content-header'); ?>

		<div class="clearfix"> </div>
	</div>
	<!---->
	<!---->

    <?php echo $__env->yieldContent('content'); ?>
	
	<!---->
	<div class="footer">
		<div class="container">
			<div class="clearfix"> </div>
			<p class="footer-class">Copyrights © 2021 Basket-Viladelima. All rights reserved | Design by <a
					href="http://w3layouts.com/">W3layouts</a></p>
		</div>
	</div>
	<!---->
	<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
	<script type="text/javascript">
		$(document).ready(function () {
			/*
			var defaults = {
			containerID: 'toTop', // fading element id
			containerHoverID: 'toTopHover', // fading element hover id
			scrollSpeed: 1200,
			easingType: 'linear' 
			};
			*/
			$().UItoTop({ easingType: 'easeOutQuart' });
		});
	</script>
	<a href="#to-top" id="toTop" style="display: block;"> <span id="toTopHover" style="opacity: 1;"> </span></a>
	<!---->
	<?php echo $__env->yieldContent('js'); ?>
	<!---->
</body>
</html><?php /**PATH C:\Instalasi Laravel\Aplikasi-Pemesanan-Lapangan-Basket-Villadelima-main\resources\views/layout/template.blade.php ENDPATH**/ ?>