<?php $__env->startSection('title', 'Badminton Field'); ?>

<?php $__env->startSection('header5', 'header5'); ?>

<?php $__env->startSection('content'); ?>
    
    <!---->
	<div class="back">
		<h2>Login</h2>
	</div>
	<!---->
	<div class="container">

		<div class="account_grid">
			<div class=" login-right">
				<h3>REGISTERED CUSTOMERS</h3>
				<p>If you have an account with us, please log in.</p>
				<?php if(session('message_success')): ?>
					<ol class="breadcrumb" style="background-color: green; color: #fff;">
						<li class=""><?php echo e(session('message_success')); ?></li>
					</ol>
				<?php endif; ?>
				
				<?php if(session('message_fail')): ?>
					<ol class="breadcrumb" style="background-color: #ff5d56; color: #fff;">
						<li class=""><?php echo e(session('message_fail')); ?></li>
					</ol>
				<?php endif; ?>
				<form action="<?php echo e(route('user.masuk')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
					<div>
						<span>Username / Email</span>
						<input type="text" class="input" name="username" placeholder="Masukkan Username / Email">
					</div>
					<div>
						<span>Password</span>
						<input type="password" class="input" name="password" placeholder="Masukkan Password">
					</div>
					<a class="forgot" href="<?php echo e(route('password.request')); ?>">Forgot Your Password?</a>
					<input type="submit" value="Login">
				</form>
			</div>
			<div class=" login-left">
				<h3>NEW CUSTOMERS</h3>
				<a class="acount-btn" href="<?php echo e(route('daftar')); ?>">Create an Account</a>
			</div>

		</div>

	</div>
	<!---->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Instalasi Laravel\Badminton Field\resources\views/masuk.blade.php ENDPATH**/ ?>